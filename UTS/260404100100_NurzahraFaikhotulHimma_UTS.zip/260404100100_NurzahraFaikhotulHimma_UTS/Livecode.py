total = 0
bayar = 0
reguler = 40000
vip = 75000
vvip = 100000


while beli:
    jenisTiket = input("Masukkan jenis tiket (Reguler/vip/vvip)")
    if reguler:
     minuman = input("Y/N")
    elif vip and vvip:
       print("Selamat anda mendapatkan minuman gratis")
    elif total >= 3:
       memberCard = input("Apa punya memberCard?(y/n)" )
       if memberCard == "y":
        total - 15 / 100
       elif memberCard == "n":
         total - 10 / 100

