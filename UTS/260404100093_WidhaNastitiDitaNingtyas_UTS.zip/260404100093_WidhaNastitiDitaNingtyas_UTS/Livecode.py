# JENIS TIKET YANG DISEDIAKAN
tiket_regular = 40000
tiket_VIP = 75000
tiket_VVIP = 100000

jenis = (input("Masukkan jenis tiket yang ingin anda beli: "))


beli = int(input("Apakah ingin membeli lebih dari satu tiket (Y/N): "))
Y = True
while Y:
    jenis_dua = (input("jenis tiket apa yang ingin ditambahkan?"))
        print("tiket anda saat ini" jenis&jenis_dua)
input("apakah ingin menambah tiket lagi? (Y/N): ")
continue

"""
pelanggan dapat membeli tiket lebih dari satu
"""


if jenis == tiket_regular:
    harga = 40000
    minuman = input("Tambahkan minuman seharga 10000? (Y/N")
    if minuman = "Y":
        harga = harga + 10000
else:
    print("Anda telah mendapatkan minuman gratis untuk jenis tiket ini")

"""
jika pelanggan membeli tiket regular mereka tidak mendapatkan minuman, jadi program menawarkan membeli minuman. jika pelanggan membeli tiket VIP DAN VVIP mereka sudah mendapatkan minuman
"""


